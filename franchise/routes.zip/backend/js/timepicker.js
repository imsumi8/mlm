$('.timepicker').timepicker({
    timeFormat: 'h:mm p',
     interval: 5,
    // minTime: '24',
    // maxTime: '11:59pm',
    startTime: '00:00',
    defaultTime: '00',
    dynamic: true,
    dropdown: true,
    scrollbar: false
});

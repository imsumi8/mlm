@extends('backend.layouts.app')
@section('title') Requisition  @endsection
@section('content')
    <div id="app">
        <new-requisition></new-requisition>
    </div>
@endsection

@section('js')

@endsection


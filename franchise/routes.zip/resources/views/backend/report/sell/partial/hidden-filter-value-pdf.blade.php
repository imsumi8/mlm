<input type="hidden" name="start_date" value="{{Request::get('start_date')}}">
<input type="hidden" name="end_date" value="{{Request::get('end_date')}}">
<input type="hidden" name="branch_id" value="{{Request::get('branch_id')}}">
<input type="hidden" name="by_duration" value="{{Request::get('by_duration')}}">
<input type="hidden" name="search_type" value="{{Request::get('search_type')}}">
<input type="hidden" name="month" value="{{Request::get('month')}}">
<input type="hidden" name="year" value="{{Request::get('year')}}">
<input type="hidden" name="product_id" value="{{Request::get('product_id')}}">
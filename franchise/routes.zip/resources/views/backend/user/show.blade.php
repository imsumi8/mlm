@extends('backend.layouts.app')
@section('title') Users @endsection
@section('content')
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <div class="row">
           //
        </div>
    </div>
    <!-- /.container-fluid -->
@endsection

@section('js')

@endsection


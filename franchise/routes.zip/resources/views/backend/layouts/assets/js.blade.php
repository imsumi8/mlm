<!-- Bootstrap core JavaScript-->
<script src="{{asset('/backend/vendor/jquery/jquery.min.js')}}"></script>
<script src="{{asset('/backend/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<!-- Core plugin JavaScript-->
<script src="{{asset('/backend/vendor/jquery-easing/jquery.easing.min.js')}}"></script>

<!-- Custom scripts for all pages-->
<script src="{{asset('/backend/vendor/datepicker/bootstrap-datepicker.js')}}"></script>
<script src="{{asset('/backend/vendor/select2/select2.full.js')}}"></script>
<script src="{{asset('/backend/vendor/parsley.js/dist/parsley.min.js')}}"></script>
<script src="{{ asset('/backend/vendor/datatables/jquery.dataTables.js') }}"></script>
<script src="{{ asset('/backend/vendor/sweetalert/sweetalert.min.js') }}"></script>
<script src="{{ asset('/backend/js/toastr.min.js') }}"></script>
<script src="{{ asset('public/backend/js/app.js') }}"></script>
<script src="{{asset('public/backend/js/script.js')}}"></script>






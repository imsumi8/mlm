@extends('backend.layouts.app')
@section('title') Purchase  @endsection

@section('css')

@endsection

@section('content')
    <div id="app">
        <new-purchase></new-purchase>
    </div>
@endsection

@section('js')

@endsection

<footer>
    {{get_option('app_name')}}, {{get_option('address')}} , {{get_option('phone')}}
</footer>
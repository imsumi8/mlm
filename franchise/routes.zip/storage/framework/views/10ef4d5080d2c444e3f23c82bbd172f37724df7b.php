<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('/backend/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('/backend/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('/backend/vendor/datepicker/bootstrap-datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/vendor/select2/select2.full.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/vendor/parsley.js/dist/parsley.min.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/vendor/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/vendor/sweetalert/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/js/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/js/script.js')); ?>"></script>





<?php /**PATH C:\xampp\htdocs\mbpos-1.3\resources\views/backend/layouts/assets/js.blade.php ENDPATH**/ ?>
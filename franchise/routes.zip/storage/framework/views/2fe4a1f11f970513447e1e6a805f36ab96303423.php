<footer>
    <?php echo e(get_option('app_name')); ?>, <?php echo e(get_option('address')); ?> , <?php echo e(get_option('phone')); ?>

</footer><?php /**PATH E:\server\MAMP\htdocs\pos\mbpos\resources\views/backend/pdf/layouts/footer.blade.php ENDPATH**/ ?>